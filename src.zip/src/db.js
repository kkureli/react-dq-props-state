var offspring = [
  { 
    "id": 1,
    "name": "JeffKatzy Katz",
    "hobby": "Never gonna give"
  },
  { 
    "id": 2,
    "name": "Rachel",
    "hobby": "You up, never gonna"
  },
  { 
    "id": 3,
    "name": "Maxwell",
    "hobby": "let you down"
  }
]


export default offspring
